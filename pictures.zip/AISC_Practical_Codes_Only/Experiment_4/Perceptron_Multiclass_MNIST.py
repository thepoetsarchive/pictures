import numpy as np
import seaborn as sns
# 1.Import Libraries

from sklearn.datasets import fetch_openml
from sklearn.linear_model import Perceptron
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# 2.Load the Dataset

# Load the MNIST dataset
mnist = fetch_openml('mnist_784')

X = mnist.data
y = mnist.target.astype(int)

print(X.shape)
print(y.shape)

print("Feature shape:", X.shape)

print("\nTarget classes:")
print(np.unique(y))

print("\nNumber of classes:", len(np.unique(y)))

# 3.Train Test Split

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.3,
    random_state=42
)

print("Training samples:", X_train.shape[0])
print("Testing samples:", X_test.shape[0])

# 4.Preprocessing

from sklearn.preprocessing import StandardScaler

# Standardize the input features
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

print("Preprocessing completed.")
print("Training shape:", X_train.shape)
print("Testing shape:", X_test.shape)

# 5.Create the Perceptron

perceptron = Perceptron(max_iter=1000, eta0=0.1)

# 6.Train the Model

perceptron.fit(X_train, y_train)

# 7.Predictions

y_pred = perceptron.predict(X_test)

print(y_pred)

# 8.Accuracy

accuracy = accuracy_score(y_test, y_pred)

print("Accuracy:", accuracy)

# 9. Confusion Matrix

conf_matrix = confusion_matrix(y_test, y_pred)

sns.heatmap(
    conf_matrix,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.ylabel('True')
plt.xlabel('False')
plt.title('Confusion Matrix')
plt.show()
