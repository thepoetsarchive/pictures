# 2.FULL ADDER

def mp_neuron(yin, threshold):
    if yin >= threshold:
        return 1
    else:
        return 0


print("\nENTER THE EIGHT INPUT COMBINATIONS")

input_combinations = []

for i in range(8):
    print("\nInput Combination", i + 1)

    x1 = int(input("Enter x1 (0 or 1): "))
    x2 = int(input("Enter x2 (0 or 1): "))
    cin = int(input("Enter Cin (0 or 1): "))

    input_combinations.append((x1, x2, cin))


w11 = 1
w12 = -1

z1_one_yins = []

for x1, x2, cin in input_combinations:
    yin = x1 * w11 + x2 * w12

    if x1 == 1 and x2 == 0:
        z1_one_yins.append(yin)

theta_z1 = min(z1_one_yins)


w21 = -1
w22 = 1

z2_one_yins = []

for x1, x2, cin in input_combinations:
    yin = x1 * w21 + x2 * w22

    if x1 == 0 and x2 == 1:
        z2_one_yins.append(yin)

theta_z2 = min(z2_one_yins)


w_z1 = 1
w_z2 = 1

xor_one_yins = []

for x1, x2, cin in input_combinations:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    yin = z1 * w_z1 + z2 * w_z2

    if z1 == 1 or z2 == 1:
        xor_one_yins.append(yin)

theta_xor = min(xor_one_yins)


w31 = 1
w32 = -1

z3_one_yins = []

for x1, x2, cin in input_combinations:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    yin = X * w31 + cin * w32

    if X == 1 and cin == 0:
        z3_one_yins.append(yin)

theta_z3 = min(z3_one_yins)


w41 = -1
w42 = 1

z4_one_yins = []

for x1, x2, cin in input_combinations:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    yin = X * w41 + cin * w42

    if X == 0 and cin == 1:
        z4_one_yins.append(yin)

theta_z4 = min(z4_one_yins)


w_z3 = 1
w_z4 = 1

sum_one_yins = []

for x1, x2, cin in input_combinations:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    z3 = mp_neuron(
        X * w31 + cin * w32,
        theta_z3
    )

    z4 = mp_neuron(
        X * w41 + cin * w42,
        theta_z4
    )

    yin = z3 * w_z3 + z4 * w_z4

    if z3 == 1 or z4 == 1:
        sum_one_yins.append(yin)

theta_sum = min(sum_one_yins)


w_c11 = 1
w_c12 = 1

c1_one_yins = []

for x1, x2, cin in input_combinations:

    yin = x1 * w_c11 + x2 * w_c12

    if x1 == 1 and x2 == 1:
        c1_one_yins.append(yin)

theta_c1 = min(c1_one_yins)


w_c21 = 1
w_c22 = 1

c2_one_yins = []

for x1, x2, cin in input_combinations:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    yin = cin * w_c21 + X * w_c22

    if cin == 1 and X == 1:
        c2_one_yins.append(yin)

theta_c2 = min(c2_one_yins)


w_c1 = 1
w_c2 = 1

carry_one_yins = []

for x1, x2, cin in input_combinations:

    C1 = mp_neuron(
        x1 * w_c11 + x2 * w_c12,
        theta_c1
    )

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    C2 = mp_neuron(
        cin * w_c21 + X * w_c22,
        theta_c2
    )

    yin = C1 * w_c1 + C2 * w_c2

    if C1 == 1 or C2 == 1:
        carry_one_yins.append(yin)

theta_carry = min(carry_one_yins)


print("\nFIRST XOR TABLE")

print("\nWeights and Threshold:")
print("w11 =", w11)
print("w12 =", w12)
print("θ1 =", theta_z1)
print("w21 =", w21)
print("w22 =", w22)
print("θ2 =", theta_z2)
print("w_z1 =", w_z1)
print("w_z2 =", w_z2)
print("θXOR =", theta_xor)

print("\n")
print(f"{'x1':<5}{'x2':<5}{'z1_in':<10}{'z1':<8}{'z2_in':<10}{'z2':<8}{'X':<8}")

for x1, x2, cin in input_combinations:

    z1_in = x1 * w11 + x2 * w12
    z1 = mp_neuron(z1_in, theta_z1)

    z2_in = x1 * w21 + x2 * w22
    z2 = mp_neuron(z2_in, theta_z2)

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    print(
        f"{x1:<5}"
        f"{x2:<5}"
        f"{z1_in:<10}"
        f"{z1:<8}"
        f"{z2_in:<10}"
        f"{z2:<8}"
        f"{X:<8}"
    )


print("\nSECOND XOR TABLE")

print("\nWeights and Threshold:")
print("w31 =", w31)
print("w32 =", w32)
print("θ3 =", theta_z3)
print("w41 =", w41)
print("w42 =", w42)
print("θ4 =", theta_z4)
print("w_z3 =", w_z3)
print("w_z4 =", w_z4)
print("θSum =", theta_sum)

print("\n")
print(f"{'X':<5}{'Cin':<6}{'z3_in':<10}{'z3':<8}{'z4_in':<10}{'z4':<8}{'Sum':<8}")

for x1, x2, cin in input_combinations:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    z3_in = X * w31 + cin * w32
    z3 = mp_neuron(z3_in, theta_z3)

    z4_in = X * w41 + cin * w42
    z4 = mp_neuron(z4_in, theta_z4)

    Sum = mp_neuron(
        z3 * w_z3 + z4 * w_z4,
        theta_sum
    )

    print(
        f"{X:<5}"
        f"{cin:<6}"
        f"{z3_in:<10}"
        f"{z3:<8}"
        f"{z4_in:<10}"
        f"{z4:<8}"
        f"{Sum:<8}"
    )


print("\nFINAL FULL ADDER TABLE")

print("\nWeights and Threshold:")
print("Carry C1:")
print("w_c11 =", w_c11)
print("w_c12 =", w_c12)
print("θc1 =", theta_c1)

print("Carry C2:")
print("w_c21 =", w_c21)
print("w_c22 =", w_c22)
print("θc2 =", theta_c2)

print("Final Carry:")
print("w_c1 =", w_c1)
print("w_c2 =", w_c2)
print("θCarry =", theta_carry)

print("\n")
print(f"{'x1':<5}{'x2':<5}{'Cin':<6}{'Sum':<8}{'Carry':<8}")

for x1, x2, cin in input_combinations:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    X = mp_neuron(
        z1 * w_z1 + z2 * w_z2,
        theta_xor
    )

    z3 = mp_neuron(
        X * w31 + cin * w32,
        theta_z3
    )

    z4 = mp_neuron(
        X * w41 + cin * w42,
        theta_z4
    )

    Sum = mp_neuron(
        z3 * w_z3 + z4 * w_z4,
        theta_sum
    )

    C1 = mp_neuron(
        x1 * w_c11 + x2 * w_c12,
        theta_c1
    )

    C2 = mp_neuron(
        cin * w_c21 + X * w_c22,
        theta_c2
    )

    Carry = mp_neuron(
        C1 * w_c1 + C2 * w_c2,
        theta_carry
    )

    print(
        f"{x1:<5}"
        f"{x2:<5}"
        f"{cin:<6}"
        f"{Sum:<8}"
        f"{Carry:<8}"
    )
