import numpy as np

# BAM (BIDIRECTIONAL ASSOCIATIVE MEMORY)

# Pattern E (5 x 3)
E = np.array([
    [ 1,  1,  1],
    [ 1, -1, -1],
    [ 1,  1,  1],
    [ 1, -1, -1],
    [ 1,  1,  1]
])

# Pattern F (5 x 3)
F = np.array([
    [ 1,  1,  1],
    [ 1,  1,  1],
    [ 1, -1, -1],
    [ 1, -1, -1],
    [ 1, -1, -1]
])

# Convert 5 x 3 matrices into 15-element vectors
E = E.flatten()
F = F.flatten()

# Target vectors
target_E = np.array([-1, 1])
target_F = np.array([1, 1])


# CALCULATE WEIGHTS

# Weight matrix for E
W1 = np.outer(E, target_E)

# Weight matrix for F
W2 = np.outer(F, target_F)

# Total weight matrix
W = W1 + W2

print("Weight Matrix W:")
print(W)


# ACTIVATION FUNCTION

def activation(net):
    if net > 0:
        return 1
    else:
        return -1


# FORWARD RECALL: X -> Y

# Test Pattern E
net_E = E @ W

output_E = np.array([
    activation(value) for value in net_E
])

print("\nForward Recall: E -> Target_E")
print("--------------------------------")
print("Input     :", E)
print("Net Input :", net_E)
print("Output    :", output_E)
print("Target    :", target_E)

if np.array_equal(output_E, target_E):
    print("Result    : Correct")
else:
    print("Result    : Incorrect")


# Test Pattern F
net_F = F @ W

output_F = np.array([
    activation(value) for value in net_F
])

print("\nForward Recall: F -> Target_F")
print("--------------------------------")
print("Input     :", F)
print("Net Input :", net_F)
print("Output    :", output_F)
print("Target    :", target_F)

if np.array_equal(output_F, target_F):
    print("Result    : Correct")
else:
    print("Result    : Incorrect")


# BACKWARD RECALL: Y -> X
# Use transpose of W

WT = W.T

# Recover Pattern E from Target_E
net_E_reverse = target_E @ WT

output_E_reverse = np.array([
    activation(value) for value in net_E_reverse
])

print("\nBackward Recall: Target_E -> E")
print("--------------------------------")
print("Input     :", target_E)
print("Net Input :", net_E_reverse)
print("Output    :", output_E_reverse)
print("Target    :", E)

if np.array_equal(output_E_reverse, E):
    print("Result    : Correct")
else:
    print("Result    : Incorrect")


# Recover Pattern F from Target_F
net_F_reverse = target_F @ WT

output_F_reverse = np.array([
    activation(value) for value in net_F_reverse
])

print("\nBackward Recall: Target_F -> F")
print("--------------------------------")
print("Input     :", target_F)
print("Net Input :", net_F_reverse)
print("Output    :", output_F_reverse)
print("Target    :", F)

if np.array_equal(output_F_reverse, F):
    print("Result    : Correct")
else:
    print("Result    : Incorrect")
