# ANFIS MODEL FOR MEDICAL DIAGNOSIS
# Application: Diabetes Prediction

import math
import random

random.seed(42)

# 1. DEFINE THE PROBLEM

print("=" * 50)
print("LAB 10: ANFIS MODEL FOR DIABETES PREDICTION")
print("=" * 50)

print("\n1. PROBLEM DEFINITION")
print("Inputs  : Glucose, BMI")
print("Output  : Diabetes (0 = No, 1 = Yes)")
print("Task    : Binary Classification")
print("Model   : Adaptive Neuro-Fuzzy Inference System")


# 2. GENERATE A SAMPLE DATASET

print("\n2. DATA PREPARATION")

data = []

# Synthetic dataset: no external CSV is required.
# Values are normalized between 0 and 1.

for i in range(400):
    glucose = random.random()
    bmi = random.random()

    # Illustrative nonlinear relationship.
    risk = (
        0.65 * glucose
        + 0.35 * bmi
        + 0.15 * glucose * bmi
    )

    # Synthetic binary target.
    outcome = 1 if risk > 0.58 else 0

    data.append([glucose, bmi, outcome])

random.shuffle(data)

train_data = data[:320]
test_data = data[320:]

print("Total samples  :", len(data))
print("Training samples:", len(train_data))
print("Testing samples :", len(test_data))
print("Input features  : Glucose, BMI")
print("Output variable : Diabetes")
print("\nFirst 5 dataset samples:")
print("Glucose    BMI       Outcome")

for row in data[:5]:
    print("%.3f      %.3f      %d" % (
        row[0], row[1], row[2]
    ))


# 3. DEFINE GAUSSIAN MEMBERSHIP FUNCTIONS

print("\n3. GAUSSIAN MEMBERSHIP FUNCTIONS")

# Gaussian membership function:
# mu(x) = exp(-(x-c)^2 / (2*sigma^2))

def gaussian_mf(x, center, sigma):
    return math.exp(
        -((x - center) ** 2) / (2 * sigma ** 2)
    )


# Two membership functions for each input.
# MF1 = Low, MF2 = High

centers = [0.25, 0.75]
sigma = 0.25

print("Gaussian MF formula:")
print("mu(x) = exp(-(x-center)^2 / (2*sigma^2))")

print("\nMembership parameters:")
print("Low  : center =", centers[0], ", sigma =", sigma)
print("High : center =", centers[1], ", sigma =", sigma)

print("\nExample membership degrees for x = 0.60:")

x = 0.60

print("Low membership :",
      round(gaussian_mf(x, centers[0], sigma), 4))

print("High membership:",
      round(gaussian_mf(x, centers[1], sigma), 4))


# 4. GENERATE FUZZY RULES

print("\n4. FUZZY RULE GENERATION")

# Two inputs, two membership functions per input.
# Total rules = 2^2 = 4

rules = [
    ("Glucose LOW", "BMI LOW"),
    ("Glucose LOW", "BMI HIGH"),
    ("Glucose HIGH", "BMI LOW"),
    ("Glucose HIGH", "BMI HIGH")
]

for i, rule in enumerate(rules):
    print("Rule", i + 1, ": IF",
          rule[0], "AND", rule[1],
          "THEN diabetes risk is predicted")

print("\nTotal fuzzy rules:", len(rules))


# 5. ANFIS INFERENCE

print("\n5. SUGENO FUZZY INFERENCE")

# Each rule has a linear consequent:
# f = a0 + a1*glucose + a2*BMI
#
# Final output:
# y = sum(w*f) / sum(w)

# Consequent parameters for each rule.
# [bias, glucose coefficient, BMI coefficient]

consequents = [
    [0.20, 0.10, 0.10],
    [0.30, 0.10, 0.10],
    [0.30, 0.10, 0.10],
    [0.40, 0.10, 0.10]
]

def infer(glucose, bmi):
    # Membership degrees for glucose
    g_low = gaussian_mf(glucose, centers[0], sigma)
    g_high = gaussian_mf(glucose, centers[1], sigma)

    # Membership degrees for BMI
    b_low = gaussian_mf(bmi, centers[0], sigma)
    b_high = gaussian_mf(bmi, centers[1], sigma)

    # Rule firing strengths using product operator
    strengths = [
        g_low * b_low,
        g_low * b_high,
        g_high * b_low,
        g_high * b_high
    ]

    # Rule outputs
    rule_outputs = []

    for params in consequents:
        output = (
            params[0]
            + params[1] * glucose
            + params[2] * bmi
        )

        rule_outputs.append(output)

    # Normalize firing strengths
    total_strength = sum(strengths) + 1e-12

    normalized = [
        w / total_strength for w in strengths
    ]

    # Weighted-average output
    prediction = sum(
        normalized[i] * rule_outputs[i]
        for i in range(len(rules))
    )

    return prediction, strengths, normalized


g, b = 0.70, 0.65

prediction, strengths, normalized = infer(g, b)

print("Example input:")
print("Glucose =", g)
print("BMI     =", b)

print("\nRule firing strengths:")

for i, w in enumerate(strengths):
    print("Rule", i + 1, ":", round(w, 5))

print("\nNormalized firing strengths:")

for i, w in enumerate(normalized):
    print("Rule", i + 1, ":", round(w, 5))

print("\nInitial Sugeno output:", round(prediction, 4))


# 6. TRAIN THE ANFIS MODEL

print("\n6. ANFIS TRAINING")

learning_rate = 0.05
epochs = 100

loss_history = []

# Train consequent parameters using gradient descent.
# Gaussian membership parameters remain fixed in this
# compact implementation.

for epoch in range(epochs):

    total_loss = 0.0

    # Accumulate gradients before updating parameters.
    gradients = [
        [0.0, 0.0, 0.0] for _ in range(len(rules))
    ]

    for row in train_data:
        glucose, bmi, actual = row

        predicted, strengths, normalized = infer(
            glucose, bmi
        )

        error = predicted - actual
        total_loss += error ** 2

        for r in range(len(rules)):
            weight = normalized[r]

            gradients[r][0] += (
                2 * error * weight
            )

            gradients[r][1] += (
                2 * error * weight * glucose
            )

            gradients[r][2] += (
                2 * error * weight * bmi
            )

    n = len(train_data)
    mse = total_loss / n
    loss_history.append(mse)

    # Update consequent parameters.
    for r in range(len(rules)):
        for j in range(3):
            gradient = gradients[r][j] / n

            consequents[r][j] -= (
                learning_rate * gradient
            )

    if epoch == 0 or (epoch + 1) % 10 == 0:
        print(
            "Epoch %3d | MSE = %.6f"
            % (epoch + 1, mse)
        )

print("\nTraining completed!")

print("\nLearned Sugeno consequent parameters:")

for i, params in enumerate(consequents):
    print(
        "Rule", i + 1,
        ": a0 =", round(params[0], 4),
        ", a1 =", round(params[1], 4),
        ", a2 =", round(params[2], 4)
    )


# ==========================================
# 7. TEST THE MODEL
# ==========================================

print("\n7. MODEL TESTING")

actual_values = []
predicted_values = []
scores = []

threshold = 0.5

for row in test_data:
    glucose, bmi, actual = row

    score, _, _ = infer(glucose, bmi)

    # Keep output within the binary score range.
    score = max(0.0, min(1.0, score))

    predicted = 1 if score >= threshold else 0

    actual_values.append(int(actual))
    predicted_values.append(predicted)
    scores.append(score)

print("Classification threshold:", threshold)

print("\nFirst 10 test predictions:")
print("Actual    Predicted    Score")

for i in range(min(10, len(test_data))):
    print(
        "  %d          %d         %.4f"
        % (
            actual_values[i],
            predicted_values[i],
            scores[i]
        )
    )


# ==========================================
# 8. EVALUATE THE MODEL
# ==========================================

print("\n8. MODEL EVALUATION")

TP = 0
TN = 0
FP = 0
FN = 0

for actual, predicted in zip(
    actual_values, predicted_values
):
    if actual == 1 and predicted == 1:
        TP += 1

    elif actual == 0 and predicted == 0:
        TN += 1

    elif actual == 0 and predicted == 1:
        FP += 1

    else:
        FN += 1

total = len(actual_values)

accuracy = (TP + TN) / max(total, 1)

precision = TP / max(TP + FP, 1)

recall = TP / max(TP + FN, 1)

f1_score = (
    2 * precision * recall
    / max(precision + recall, 1e-12)
)

print("Accuracy : %.4f (%.2f%%)" % (
    accuracy, accuracy * 100
))

print("Precision: %.4f" % precision)

print("Recall   : %.4f" % recall)

print("F1-score : %.4f" % f1_score)

print("\nConfusion Matrix:")
print("                 Predicted")
print("                 0       1")
print("Actual 0       %4d    %4d" % (TN, FP))
print("Actual 1       %4d    %4d" % (FN, TP))

print("\nConfusion matrix interpretation:")
print("True Negative :", TN)
print("False Positive:", FP)
print("False Negative:", FN)
print("True Positive :", TP)


# ==========================================
# 9. TRAINING LOSS SUMMARY
# ==========================================

print("\n9. TRAINING LOSS SUMMARY")

print("Initial MSE:", round(loss_history[0], 6))
print("Final MSE  :", round(loss_history[-1], 6))

print("\nLoss at selected epochs:")

for i in range(0, epochs, 10):
    print(
        "Epoch %3d : %.6f"
        % (i + 1, loss_history[i])
    )


# ==========================================
# 10. PREDICT A NEW SAMPLE
# ==========================================

print("\n10. NEW DIABETES PREDICTION")

new_glucose = 0.80
new_bmi = 0.70

score, strengths, normalized = infer(
    new_glucose, new_bmi
)

score = max(0.0, min(1.0, score))

diagnosis = 1 if score >= threshold else 0

print("Glucose input:", new_glucose)
print("BMI input    :", new_bmi)
print("Risk score   :", round(score, 4))

if diagnosis == 1:
    print("Model prediction: DIABETES CLASS (1)")
else:
    print("Model prediction: NON-DIABETES CLASS (0)")


# ==========================================
# END OF PROGRAM
# ==========================================

print("\n" + "=" * 50)
print("ANFIS EXPERIMENT COMPLETED SUCCESSFULLY")
print("=" * 50)

print("\nNote:")
print("This is an educational demonstration using")
print("synthetic data, not a clinical diagnostic model.")

# ==========================================
# 11. TRAINING AND TESTING ACCURACY
# ==========================================

def calculate_accuracy(dataset):
    correct = 0

    for row in dataset:
        glucose, bmi, actual = row

        score, _, _ = infer(glucose, bmi)

        # Keep score between 0 and 1
        score = max(0.0, min(1.0, score))

        # Convert score into class
        predicted = 1 if score >= threshold else 0

        if predicted == int(actual):
            correct += 1

    accuracy = correct / len(dataset) * 100
    return accuracy


# Calculate accuracy on training data
train_accuracy = calculate_accuracy(train_data)

# Calculate accuracy on testing data
test_accuracy = calculate_accuracy(test_data)

# Display results

print("TRAINING AND TESTING ACCURACY")

print("Training Samples :", len(train_data))
print("Testing Samples  :", len(test_data))

print("Training Accuracy: {:.2f}%".format(train_accuracy))
print("Testing Accuracy : {:.2f}%".format(test_accuracy))
