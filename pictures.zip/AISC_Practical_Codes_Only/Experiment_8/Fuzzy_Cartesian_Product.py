# Question 2: Cartesian Product of Two Fuzzy Sets

A = [0.3, 0.7, 1.0]
B = [0.4, 0.9]

X = ["x1", "x2", "x3"]
Y = ["y1", "y2"]

# Cartesian product using the minimum operator
R = []

for a in A:
    row = []
    for b in B:
        row.append(min(a, b))
    R.append(row)

# Display the Cartesian product
print("Fuzzy Set A:", A)
print("Fuzzy Set B:", B)

print("\nCartesian Product R = A x B:")

for i, row in enumerate(R):
    print(X[i], row)
