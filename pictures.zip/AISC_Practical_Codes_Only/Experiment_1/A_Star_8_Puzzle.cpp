#include <bits/stdc++.h>
using namespace std;

struct Node {
    vector<vector<int>> mat;
    int x, y;
    int g, h;
    Node* parent;
};

vector<vector<int>> goal;

int calcH(vector<vector<int>>& mat) {
    int count = 0;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (mat[i][j] != 0 && mat[i][j] != goal[i][j])
                count++;
    return count;
}

string toStr(vector<vector<int>>& mat) {
    string s;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            s += char(mat[i][j] + '0');
    return s;
}

struct cmp {
    bool operator()(Node* a, Node* b) {
        return (a->g + a->h) > (b->g + b->h);
    }
};

void solve(vector<vector<int>> start, int x, int y) {
    priority_queue<Node*, vector<Node*>, cmp> pq;
    set<string> visited;
    Node* root = new Node{start, x, y, 0, calcH(start), nullptr};
    pq.push(root);

    int dx[4] = {1, -1, 0, 0};
    int dy[4] = {0, 0, 1, -1};

    while (!pq.empty()) {
        Node* cur = pq.top();
        pq.pop();

        if (cur->mat == goal) {
            cout << "Goal reached in " << cur->g << " steps\n\n";
            vector<vector<vector<int>>> path;
            for (Node* temp = cur; temp != nullptr; temp = temp->parent)
                path.push_back(temp->mat);
            reverse(path.begin(), path.end());

            for (int i = 0; i < (int)path.size(); i++) {
                cout << "Step " << i << ":\n";
                for (auto row : path[i]) {
                    for (auto val : row) cout << val << " ";
                    cout << "\n";
                }
                cout << "\n";
            }
            return;
        }

        visited.insert(toStr(cur->mat));
        for (int i = 0; i < 4; i++) {
            int nx = cur->x + dx[i], ny = cur->y + dy[i];
            if (nx >= 0 && nx < 3 && ny >= 0 && ny < 3) {
                Node* next = new Node;
                next->mat = cur->mat;
                swap(next->mat[cur->x][cur->y], next->mat[nx][ny]);
                next->x = nx;
                next->y = ny;
                next->g = cur->g + 1;
                next->h = calcH(next->mat);
                next->parent = cur;
                if (visited.count(toStr(next->mat)) == 0) pq.push(next);
                else delete next;
            }
        }
    }
    cout << "No solution\n";
}

int main() {
    vector<vector<int>> start(3, vector<int>(3));
    goal.resize(3, vector<int>(3));
    int x = 0, y = 0;

    cout << "Enter initial state (0 for blank):\n";
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            cin >> start[i][j];
            if (start[i][j] == 0) { x = i; y = j; }
        }

    cout << "Enter goal state:\n";
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> goal[i][j];

    solve(start, x, y);
    return 0;
}
