# Binary Classification: Student Pass/Fail Prediction

import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

np.random.seed(42)

study_hours = np.random.uniform(1, 10, 100)
attendance = np.random.uniform(50, 100, 100)

X = np.column_stack((study_hours, attendance))

y = ((study_hours >= 5) & (attendance >= 75)).astype(int)

y[47] = 1 - y[47]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.5, random_state=42
)

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = MLPClassifier(
    hidden_layer_sizes=(10, 5),
    activation='relu',
    solver='lbfgs',
    max_iter=5000,
    random_state=42
)

model.fit(X_train_scaled, y_train)

predictions = model.predict(X_test_scaled)

print("Actual Test Labels: ", y_test)
print("Predicted Test Labels: ", predictions)
print("Accuracy Score: ", accuracy_score(y_test, predictions))
