import numpy as np
import matplotlib.pyplot as plt
import skfuzzy as fuzz
from skfuzzy import control as ctrl

roll_error = ctrl.Antecedent(
    np.arange(-30, 31, 1), "roll_error"
)

roll_rate = ctrl.Antecedent(
    np.arange(-10, 10.1, 0.1), "roll_rate"
)

motor_correction = ctrl.Consequent(
    np.arange(-100, 101, 1), "motor_correction"
)

motor_correction.defuzzify_method = "centroid"

roll_error["negative"] = fuzz.trimf(
    roll_error.universe, [-30, -30, 0]
)
roll_error["zero"] = fuzz.trimf(
    roll_error.universe, [-30, 0, 30]
)
roll_error["positive"] = fuzz.trimf(
    roll_error.universe, [0, 30, 30]
)

roll_rate["negative"] = fuzz.trimf(
    roll_rate.universe, [-10, -10, 0]
)
roll_rate["zero"] = fuzz.trimf(
    roll_rate.universe, [-10, 0, 10]
)
roll_rate["positive"] = fuzz.trimf(
    roll_rate.universe, [0, 10, 10]
)

motor_correction["strong_negative"] = fuzz.trimf(
    motor_correction.universe, [-100, -100, -50]
)
motor_correction["negative"] = fuzz.trimf(
    motor_correction.universe, [-100, -50, 0]
)
motor_correction["zero"] = fuzz.trimf(
    motor_correction.universe, [-50, 0, 50]
)
motor_correction["positive"] = fuzz.trimf(
    motor_correction.universe, [0, 50, 100]
)
motor_correction["strong_positive"] = fuzz.trimf(
    motor_correction.universe, [50, 100, 100]
)

rule_specs = [
    ("negative", "negative", "strong_negative"),
    ("negative", "zero", "negative"),
    ("negative", "positive", "zero"),
    ("zero", "negative", "positive"),
    ("zero", "zero", "zero"),
    ("zero", "positive", "negative"),
    ("positive", "negative", "zero"),
    ("positive", "zero", "positive"),
    ("positive", "positive", "strong_positive"),
]

rules = []

for error_set, rate_set, output_set in rule_specs:
    rules.append(
        ctrl.Rule(
            roll_error[error_set] & roll_rate[rate_set],
            motor_correction[output_set]
        )
    )

control_system = ctrl.ControlSystem(rules)
controller = ctrl.ControlSystemSimulation(control_system)

print("FUZZY CONTROLLER FOR AUTONOMOUS DRONE STABILIZATION")

try:
    error = float(input("Enter roll error (-30 to 30 degrees): "))
    rate = float(input("Enter roll angular velocity (-10 to 10 deg/s): "))

    if not np.isfinite(error) or not np.isfinite(rate):
        raise ValueError("Inputs must be finite numbers.")

    if not -30 <= error <= 30:
        raise ValueError("Roll error must be between -30 and 30.")

    if not -10 <= rate <= 10:
        raise ValueError("Roll rate must be between -10 and 10.")

except ValueError as exc:
    print("Invalid input:", exc)
    raise SystemExit(1)

error_membership = {
    name: fuzz.interp_membership(
        roll_error.universe,
        roll_error[name].mf,
        error
    )
    for name in ["negative", "zero", "positive"]
}

rate_membership = {
    name: fuzz.interp_membership(
        roll_rate.universe,
        roll_rate[name].mf,
        rate
    )
    for name in ["negative", "zero", "positive"]
}

print("\n1. FUZZIFICATION")
print(f"\nRoll error = {error:.2f} degrees")

for name, value in error_membership.items():
    print(f"Membership in {name:10s} = {value:.4f}")

print(f"\nRoll angular velocity = {rate:.2f} degrees/second")

for name, value in rate_membership.items():
    print(f"Membership in {name:10s} = {value:.4f}")

output_universe = motor_correction.universe

aggregated_output = np.zeros_like(
    output_universe, dtype=float
)

print("\n2. RULE EVALUATION")

for i, (error_set, rate_set, output_set) in enumerate(
    rule_specs, start=1
):
    firing_strength = min(
        error_membership[error_set],
        rate_membership[rate_set]
    )

    print(
        f"Rule {i}: {error_set} AND {rate_set} -> {output_set}"
    )
    print(f"Firing strength = {firing_strength:.4f}")

    output_mf = motor_correction[output_set].mf

    clipped_output = np.fmin(
        firing_strength, output_mf
    )

    aggregated_output = np.fmax(
        aggregated_output, clipped_output
    )

print("\n3. CENTROID DEFUZZIFICATION")
print("Formula: z* = integral(z * mu(z)) / integral(mu(z))")

centroid_value = fuzz.defuzz(
    output_universe,
    aggregated_output,
    "centroid"
)

controller.input["roll_error"] = error
controller.input["roll_rate"] = rate
controller.compute()

controller_value = controller.output["motor_correction"]

numerator = np.trapezoid(
    output_universe * aggregated_output,
    output_universe
)

denominator = np.trapezoid(
    aggregated_output,
    output_universe
)

print("\nAggregated output calculations:")
print(f"Numerator   = {numerator:.4f}")
print(f"Denominator = {denominator:.4f}")

if denominator > 0:
    print(
        f"Centroid by numerical integration = "
        f"{numerator / denominator:.4f}%"
    )

print(f"Centroid defuzzified value = {centroid_value:.4f}%")
print(f"Built-in controller output = {controller_value:.4f}%")
print(
    f"Absolute difference = "
    f"{abs(centroid_value - controller_value):.6f}"
)

print("\n4. FINAL RESULT")
print(f"Roll error            : {error:.2f} degrees")
print(f"Roll angular velocity : {rate:.2f} degrees/second")
print(f"Motor correction      : {centroid_value:.4f}%")

if centroid_value > 5:
    print("Controller decision   : Positive correction")
elif centroid_value < -5:
    print("Controller decision   : Negative correction")
else:
    print("Controller decision   : Near-zero correction")

fig, axes = plt.subplots(1, 3, figsize=(18, 5.5))

for name in ["negative", "zero", "positive"]:
    axes[0].plot(
        roll_error.universe,
        roll_error[name].mf,
        label=name
    )

axes[0].axvline(
    error, color="black", linestyle="--",
    label=f"Input = {error:g}"
)
axes[0].set_title("Roll Error Membership Functions")
axes[0].set_xlabel("Roll error (degrees)")
axes[0].set_ylabel("Membership")
axes[0].set_ylim(0, 1.05)
axes[0].grid(True, alpha=0.3)
axes[0].legend()

for name in ["negative", "zero", "positive"]:
    axes[1].plot(
        roll_rate.universe,
        roll_rate[name].mf,
        label=name
    )

axes[1].axvline(
    rate, color="black", linestyle="--",
    label=f"Input = {rate:g}"
)
axes[1].set_title("Roll Rate Membership Functions")
axes[1].set_xlabel("Roll rate (degrees/second)")
axes[1].set_ylabel("Membership")
axes[1].set_ylim(0, 1.05)
axes[1].grid(True, alpha=0.3)
axes[1].legend()

for name in [
    "strong_negative", "negative", "zero",
    "positive", "strong_positive"
]:
    axes[2].plot(
        output_universe,
        motor_correction[name].mf,
        linestyle=":",
        alpha=0.65,
        label=name
    )

axes[2].fill_between(
    output_universe,
    aggregated_output,
    alpha=0.3,
    label="Aggregated output"
)

axes[2].plot(
    output_universe,
    aggregated_output,
    linewidth=2,
    label="Aggregated boundary"
)

axes[2].axvline(
    centroid_value,
    color="black",
    linestyle="--",
    linewidth=2,
    label=f"Centroid = {centroid_value:.2f}%"
)

axes[2].set_title("Output and Centroid Defuzzification")
axes[2].set_xlabel("Motor correction (%)")
axes[2].set_ylabel("Membership")
axes[2].set_xlim(-100, 100)
axes[2].set_ylim(0, 1.05)
axes[2].grid(True, alpha=0.3)
axes[2].legend(fontsize=8)

plt.tight_layout()
plt.show()
