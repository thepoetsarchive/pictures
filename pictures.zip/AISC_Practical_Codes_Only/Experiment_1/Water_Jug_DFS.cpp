#include <bits/stdc++.h>
using namespace std;

int m, n, d;
vector<vector<bool>> visited;
vector<pair<int,int>> path;
vector<pair<int,int>> result;
bool found = false;

void dfs(int jug1, int jug2)
{
    if (found) return;

    visited[jug1][jug2] = true;
    path.push_back({jug1, jug2});

    if (jug2 == d)
    {
        result = path;
        found = true;
        return;
    }

    // 1. Fill jug1
    if (!visited[m][jug2])
        dfs(m, jug2);

    // 2. Fill jug2
    if (!visited[jug1][n])
        dfs(jug1, n);

    // 3. Empty jug1
    if (!visited[0][jug2])
        dfs(0, jug2);

    // 4. Empty jug2
    if (!visited[jug1][0])
        dfs(jug1, 0);

    // 5. Pour jug1 to jug2
    int pour1to2 = min(jug1, n - jug2);
    if (!visited[jug1 - pour1to2][jug2 + pour1to2])
        dfs(jug1 - pour1to2, jug2 + pour1to2);

    // 6. Pour jug2 to jug1
    int pour2to1 = min(jug2, m - jug1);
    if (!visited[jug1 + pour2to1][jug2 - pour2to1])
        dfs(jug1 + pour2to1, jug2 - pour2to1);

    // backtrack
    path.pop_back();
}

int main()
{
    m = 3; n = 4; d = 2;

    visited.assign(m+1, vector<bool>(n+1, false));

    dfs(0, 0);

    if (found)
    {
        cout << "Path (DFS):\n";
        for (auto &p : result)
            cout << "(" << p.first << ", " << p.second << ")\n";

        cout << "Steps = " << result.size() - 1 << endl;
    }
    else
        cout << "No solution\n";
}
