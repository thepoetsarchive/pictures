# SMART ONLINE SHOPPING AGENT
# 1. Product Recommendation
# 2. Delivery Recommendation
# Agent Type: Utility-Based Agent


products = [
    {
        "id": "P1",
        "name": "Laptop A",
        "price": 65000,
        "ram": 16,
        "storage": 512,
        "battery": 8,
        "rating": 4.4
    },

    {
        "id": "P2",
        "name": "Laptop B",
        "price": 68000,
        "ram": 32,
        "storage": 1000,
        "battery": 10,
        "rating": 4.7
    },

    {
        "id": "P3",
        "name": "Laptop C",
        "price": 55000,
        "ram": 8,
        "storage": 512,
        "battery": 10,
        "rating": 4.3
    },

    {
        "id": "P4",
        "name": "Laptop D",
        "price": 75000,
        "ram": 32,
        "storage": 1000,
        "battery": 9,
        "rating": 4.8
    }
]


# DELIVERY OPTIONS

delivery_options = [
    {
        "id": "D1",
        "type": "Standard",
        "days": 4,
        "cost": 50,
        "available": True
    },

    {
        "id": "D2",
        "type": "Express",
        "days": 2,
        "cost": 100,
        "available": True
    },

    {
        "id": "D3",
        "type": "Same-Day",
        "days": 1,
        "cost": 250,
        "available": True
    },

    {
        "id": "D4",
        "type": "Economy",
        "days": 6,
        "cost": 30,
        "available": True
    }
]


# Product Recommendation Utility
def get_product_requirements():

    print("\nEnter your product requirements")

    # Maximum budget

    while True:

        budget = input(
            "Maximum budget (₹): "
        ).strip()

        if budget.isdigit():

            budget = int(budget)
            break

        print("Please enter a valid budget.")


    # Minimum RAM

    while True:

        ram = input(
            "Minimum RAM required (GB): "
        ).strip()

        if ram.isdigit():

            ram = int(ram)
            break

        print("Please enter a valid RAM value.")


    # Minimum storage

    while True:

        storage = input(
            "Minimum storage required (GB): "
        ).strip()

        if storage.isdigit():

            storage = int(storage)
            break

        print("Please enter a valid storage value.")


    # Minimum rating

    while True:

        rating = input(
            "Minimum rating required (0-5): "
        ).strip()

        try:

            rating = float(rating)

            if 0 <= rating <= 5:
                break

        except ValueError:
            pass

        print("Please enter a rating between 0 and 5.")


    return budget, ram, storage, rating


# Calculate product utility
def calculate_product_utility(
    product,
    budget,
    ram_required,
    storage_required,
    min_rating
):

    # Reject products that don't satisfy
    # mandatory requirements.

    if product["price"] > budget:
        return -1

    if product["ram"] < ram_required:
        return -1

    if product["storage"] < storage_required:
        return -1

    if product["rating"] < min_rating:
        return -1


    score = 0


    # Price
    if product["price"] <= budget * 0.80:

        score += 30

    elif product["price"] <= budget:

        score += 20


    # RAM
    if product["ram"] >= 32:

        score += 25

    elif product["ram"] >= 16:

        score += 20


    # Storage
    if product["storage"] >= 1000:

        score += 20

    elif product["storage"] >= 512:

        score += 15


    # Battery
    if product["battery"] >= 10:

        score += 15

    elif product["battery"] >= 8:

        score += 10


    # Rating
    if product["rating"] >= 4.7:

        score += 10

    elif product["rating"] >= 4.5:

        score += 8

    else:

        score += 5


    return score


# Select best product
def select_best_product(
    budget,
    ram_required,
    storage_required,
    min_rating
):

    best_product = None
    best_score = -1


    for product in products:

        score = calculate_product_utility(
            product,
            budget,
            ram_required,
            storage_required,
            min_rating
        )


        # Ignore unsuitable products

        if score == -1:
            continue


        # Select product with highest utility

        if score > best_score:

            best_score = score
            best_product = product


    return best_product, best_score


# Delivery Recommendation Utility
def get_delivery_requirements():

    print("\nEnter delivery requirements")


    # Maximum number of days
    # within which customer wants delivery.

    while True:

        max_days = input(
            "Maximum acceptable delivery time (days): "
        ).strip()

        if max_days.isdigit():

            max_days = int(max_days)
            break

        print("Please enter a valid number.")


    # Maximum delivery cost

    while True:

        max_cost = input(
            "Maximum acceptable delivery cost (₹): "
        ).strip()

        if max_cost.isdigit():

            max_cost = int(max_cost)
            break

        print("Please enter a valid cost.")


    return max_days, max_cost


# Calculate delivery utility
def calculate_delivery_utility(
    delivery,
    max_days,
    max_cost
):

    # Ignore unavailable delivery options
    if not delivery["available"]:
        return -1

    # Mandatory constraints
    if delivery["days"] > max_days:
        return -1

    if delivery["cost"] > max_cost:
        return -1

    score = 0

    # Delivery speed
    # Speed has the highest importance
    if delivery["days"] == 1:
        score += 80

    elif delivery["days"] == 2:
        score += 50

    elif delivery["days"] <= 4:
        score += 30

    else:
        score += 10

    # Delivery cost
    if delivery["cost"] <= max_cost * 0.40:
        score += 20

    elif delivery["cost"] <= max_cost * 0.70:
        score += 15

    else:
        score += 10

    return score

# Select best delivery option
def select_best_delivery(
    max_days,
    max_cost
):

    best_delivery = None
    best_score = -1


    for delivery in delivery_options:

        score = calculate_delivery_utility(
            delivery,
            max_days,
            max_cost
        )


        # Ignore unsuitable options

        if score == -1:
            continue


        # Select highest utility

        if score > best_score:

            best_score = score
            best_delivery = delivery


    return best_delivery, best_score


# DISPLAY FINAL RECOMMENDATION
def display_final_recommendation(
    product,
    product_score,
    delivery,
    delivery_score
):

    print("\n" + "=" * 55)
    print("             FINAL SHOPPING RECOMMENDATION")
    print("=" * 55)


    print("\nPRODUCT")

    print(
        f"Product      : {product['name']}"
    )

    print(
        f"Price        : ₹{product['price']}"
    )

    print(
        f"RAM          : {product['ram']} GB"
    )

    print(
        f"Storage      : {product['storage']} GB"
    )

    print(
        f"Battery      : {product['battery']} hours"
    )

    print(
        f"Rating       : {product['rating']}/5"
    )

    print(
        f"Product Score: {product_score}"
    )


    print("\nDELIVERY")

    print(
        f"Type         : {delivery['type']}"
    )

    print(
        f"Delivery Time: {delivery['days']} days"
    )

    print(
        f"Delivery Cost: ₹{delivery['cost']}"
    )

    print(
        f"Delivery Score: {delivery_score}"
    )


    print("\n" + "-" * 55)

    print(
        f"Recommended Product : {product['name']}"
    )

    print(
        f"Recommended Delivery: {delivery['type']}"
    )

    print(
        "\nThe recommendations were selected "
        "using utility-based decision making."
    )


# MAIN SMART SHOPPING AGENT
def run_agent():

    print("=" * 55)
    print("           SMART ONLINE SHOPPING AGENT")
    print("=" * 55)

    print(
        "\nThe agent provides two functionalities:"
    )

    print(
        "1. Product Recommendation"
    )

    print(
        "2. Delivery Recommendation"
    )


    # FUNCTION 1: PRODUCT RECOMMENDATION
    (
        budget,
        ram_required,
        storage_required,
        min_rating
    ) = get_product_requirements()


    print(
        "\nFinding the best product..."
    )


    best_product, product_score = select_best_product(
        budget,
        ram_required,
        storage_required,
        min_rating
    )


    if best_product is None:

        print(
            "\nNo product satisfies "
            "your requirements."
        )

        return


    print("\nBest product found!")

    print(
        f"Recommended Product: "
        f"{best_product['name']}"
    )

    print(
        f"Utility Score: {product_score}"
    )


    # FUNCTION 2: DELIVERY RECOMMENDATION
    print(
        "\nNow selecting the best delivery option "
        "for the selected product."
    )


    max_days, max_cost = get_delivery_requirements()


    best_delivery, delivery_score = (
        select_best_delivery(
            max_days,
            max_cost
        )
    )


    if best_delivery is None:

        print(
            "\nNo delivery option satisfies "
            "your requirements."
        )

        return


    # FINAL RESULT
    display_final_recommendation(
        best_product,
        product_score,
        best_delivery,
        delivery_score
    )


# PROGRAM START

if __name__ == "__main__":

    run_agent()
