import pandas as pd

# Perceptron Learning Rule
# AND Gate using Bipolar Inputs

# Training data
data = [
    [1,  1,  1],    # 1 AND 1 = 1
    [1, -1, -1],    # 1 AND -1 = -1
    [-1, 1, -1],    # -1 AND 1 = -1
    [-1, -1, -1]    # -1 AND -1 = -1
]

alpha = 1

# Initial weights and bias
w1 = 0
w2 = 0
b = 0

epoch = 1
final_table = []

while True:

    weight_changed = False

    for x1, x2, t in data:

        # Calculate Yin
        yin = b + (w1 * x1) + (w2 * x2)

        # Bipolar sign activation function
        if yin >= 0:
            y = 1
        else:
            y = -1

        # Calculate weight changes
        if y != t:
            delta_w1 = alpha * t * x1
            delta_w2 = alpha * t * x2
            delta_b = alpha * t

            # Update weights
            new_w1 = w1 + delta_w1
            new_w2 = w2 + delta_w2
            new_b = b + delta_b

            weight_changed = True

        else:
            # No change if output is correct
            delta_w1 = 0
            delta_w2 = 0
            delta_b = 0

            new_w1 = w1
            new_w2 = w2
            new_b = b

        # Store the row
        final_table.append([
            epoch,
            x1,
            x2,
            t,
            b,
            alpha,
            yin,
            y,
            w1,
            w2,
            delta_w1,
            delta_w2,
            delta_b,
            new_w1,
            new_w2,
            new_b
        ])

        # Update weights for next training pattern
        w1 = new_w1
        w2 = new_w2
        b = new_b

    # If no weights changed during the complete epoch,
    # training has converged.
    if not weight_changed:
        break

    epoch += 1


# -----------------------------
# Create Final Table
# -----------------------------

columns = [
    "Epoch",
    "X1",
    "X2",
    "Target (t)",
    "Bias (b)",
    "Alpha",
    "Yin",
    "Y",
    "W1",
    "W2",
    "Delta W1",
    "Delta W2",
    "Delta b",
    "New W1",
    "New W2",
    "New b"
]

df = pd.DataFrame(final_table, columns=columns)

print("\nPERCEPTRON LEARNING RULE - AND GATE")
print("=" * 100)
print(df.to_string(index=False))

print("\n" + "=" * 100)
print("FINAL WEIGHTS")
print("=" * 100)
print("W1 =", w1)
print("W2 =", w2)
print("Bias =", b)
print("Number of epochs =", epoch)
