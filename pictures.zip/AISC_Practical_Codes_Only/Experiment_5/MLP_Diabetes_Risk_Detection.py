# Diabetes Risk Detection

import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report

np.random.seed(15)

bmi = np.random.uniform(18, 38, 100)
age = np.random.randint(21, 75, 100)
glucose = np.random.uniform(65, 190, 100)

X = np.column_stack((bmi, age, glucose))

y = ((glucose > 135) | ((bmi > 29) & (age > 50))).astype(int)

noise = np.random.random(100) < 0.10

y[noise] = 1 - y[noise]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=15
)

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = MLPClassifier(
    hidden_layer_sizes=(10, 5),
    activation='relu',
    max_iter=1500,
    random_state=15
)

model.fit(X_train_scaled, y_train)

predictions = model.predict(X_test_scaled)

print("Actual Test Labels: ", y_test)
print("Predicted Test Labels: ", predictions)
print("Accuracy Score: ", accuracy_score(y_test, predictions))

print("\nClassification Report:\n")
print(classification_report(y_test, predictions))
