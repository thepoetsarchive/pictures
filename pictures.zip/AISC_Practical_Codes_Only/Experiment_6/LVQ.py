import numpy as np

# LEARNING VECTOR QUANTIZATION (LVQ)

alpha = 0.1

# Initial reference weight vectors
w1 = np.array([0, 0, 1, 1], dtype=float)
w2 = np.array([1, 0, 0, 0], dtype=float)

# Training vectors and their target classes
training_data = [
    (np.array([0, 0, 0, 1], dtype=float), 2),
    (np.array([1, 0, 0, 0], dtype=float), 2),
    (np.array([1, 1, 0, 0], dtype=float), 1)
]

# Reference vector classes
class_w1 = 1
class_w2 = 2


def lvq_step(X, target, w1, w2, alpha):
    print("\\n" + "=" * 65)
    print("INPUT VECTOR:", X.astype(int))
    print("TARGET CLASS:", target)

    # Calculate Euclidean distances
    d1 = np.linalg.norm(X - w1)
    d2 = np.linalg.norm(X - w2)

    print("Distance from w1:", d1)
    print("Distance from w2:", d2)

    # Select winning vector
    if d1 < d2:
        old = w1.copy()
        winner_class = class_w1
        winner = 1
    else:
        old = w2.copy()
        winner_class = class_w2
        winner = 2

    print("Winning vector: w" + str(winner))

    # Update winner according to classification
    if winner_class == target:
        updated = old + alpha * (X - old)
        print("\\nCorrect classification.")
        print("Moving weights towards input.")
    else:
        updated = old - alpha * (X - old)
        print("\\nIncorrect classification.")
        print("Moving weights away from input.")

    if winner == 1:
        w1 = updated
    else:
        w2 = updated

    print("Updated winner vector:", updated)
    print("Updated weight matrix:")
    print(np.column_stack((w1, w2)))

    return w1, w2


for X, target in training_data:
    w1, w2 = lvq_step(X, target, w1, w2, alpha)

print("\\n" + "=" * 65)
print("FINAL LVQ WEIGHT VECTORS")
print("w1 =", w1)
print("w2 =", w2)
