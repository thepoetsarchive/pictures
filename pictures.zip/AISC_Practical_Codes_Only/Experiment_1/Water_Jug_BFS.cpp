#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;

int minSteps(int m, int n, int d) {
    if (d > max(m, n)) return -1;

    queue<vector<int>> q; // jug1, jug2, steps
    vector<vector<bool>> visited(m + 1, vector<bool>(n + 1, false));
    map<pair<int, int>, pair<int, int>> parent;

    q.push({0, 0, 0});
    visited[0][0] = true;

    while (!q.empty()) {
        auto curr = q.front();
        q.pop();

        int jug1 = curr[0], jug2 = curr[1], steps = curr[2];
        if (jug2 == d) {
            vector<pair<int, int>> path;
            pair<int, int> cur = {jug1, jug2};
            while (!(cur.first == 0 && cur.second == 0)) {
                path.push_back(cur);
                cur = parent[cur];
            }
            path.push_back({0, 0});
            reverse(path.begin(), path.end());
            cout << "Optimal Path:\n";
            for (auto &p : path)
                cout << "(" << p.first << ", " << p.second << ")\n";
            return steps;
        }

        // Fill jug1
        if (!visited[m][jug2]) {
            visited[m][jug2] = true;
            parent[{m, jug2}] = {jug1, jug2};
            q.push({m, jug2, steps + 1});
        }
        // Fill jug2
        if (!visited[jug1][n]) {
            visited[jug1][n] = true;
            parent[{jug1, n}] = {jug1, jug2};
            q.push({jug1, n, steps + 1});
        }
        // Empty jug1
        if (!visited[0][jug2]) {
            visited[0][jug2] = true;
            parent[{0, jug2}] = {jug1, jug2};
            q.push({0, jug2, steps + 1});
        }
        // Empty jug2
        if (!visited[jug1][0]) {
            visited[jug1][0] = true;
            parent[{jug1, 0}] = {jug1, jug2};
            q.push({jug1, 0, steps + 1});
        }
        // Pour jug1 into jug2
        int pour1to2 = min(jug1, n - jug2);
        if (!visited[jug1 - pour1to2][jug2 + pour1to2]) {
            visited[jug1 - pour1to2][jug2 + pour1to2] = true;
            parent[{jug1 - pour1to2, jug2 + pour1to2}] = {jug1, jug2};
            q.push({jug1 - pour1to2, jug2 + pour1to2, steps + 1});
        }
        // Pour jug2 into jug1
        int pour2to1 = min(jug2, m - jug1);
        if (!visited[jug1 + pour2to1][jug2 - pour2to1]) {
            visited[jug1 + pour2to1][jug2 - pour2to1] = true;
            parent[{jug1 + pour2to1, jug2 - pour2to1}] = {jug1, jug2};
            q.push({jug1 + pour2to1, jug2 - pour2to1, steps + 1});
        }
    }
    return -1;
}

int main() {
    int m = 3, n = 4, d = 2;
    int ans = minSteps(m, n, d);
    if (ans != -1) cout << "Minimum Steps = " << ans << endl;
    else cout << "Solution not possible\n";
    return 0;
}
