# Question 9: Fuzzy Set Operations

x = [1, 2, 3, 4]

A = [0.3, 0.3, 0.4, 0.5]
B = [0.1, 0.2, 0.2, 0.1]

algebraic_sum = [
    a + b - a * b for a, b in zip(A, B)
]

algebraic_product = [
    a * b for a, b in zip(A, B)
]

bounded_sum = [
    min(1, a + b) for a, b in zip(A, B)
]

bounded_difference = [
    max(0, a - b) for a, b in zip(A, B)
]

print("Fuzzy Set A:", A)
print("Fuzzy Set B:", B)

print("\n(a) Algebraic Sum:", [round(v, 2) for v in algebraic_sum])
print("(b) Algebraic Product:", [round(v, 2) for v in algebraic_product])
print("(c) Bounded Sum:", [round(v, 2) for v in bounded_sum])
print("(d) Bounded Difference:", [round(v, 2) for v in bounded_difference])
