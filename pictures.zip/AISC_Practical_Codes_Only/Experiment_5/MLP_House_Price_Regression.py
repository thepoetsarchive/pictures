# House Price Prediction using Regression

import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score

np.random.seed(10)

size = np.random.uniform(500, 3000, 100)
rooms = np.random.randint(1, 6, 100)
location_value = np.random.uniform(1, 10, 100)

X = np.column_stack((size, rooms, location_value))

y = (size * 0.01) + (rooms * 2.5) + (location_value * 1.5)

y += np.random.normal(0, 1.2, 100)

y = np.clip(y, 5, 50)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=10
)

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

model = MLPRegressor(
    hidden_layer_sizes=(16, 8),
    activation='relu',
    max_iter=2000,
    random_state=10
)

model.fit(X_train, y_train)

predictions = model.predict(X_test)

print("Actual House Prices:", np.round(y_test[:5], 2))
print("Predicted House Prices:", np.round(predictions[:5], 2))
print("Mean Squared Error:", round(mean_squared_error(y_test, predictions), 4))
print("R2 Score:", round(r2_score(y_test, predictions), 4))
