import math
from tabulate import tabulate


# SIGMOID FUNCTION

def sigmoid(x):
    return 1 / (1 + math.exp(-x))


# INPUTS AND TARGET

x1, x2 = 0, 1
t = 1

# INITIAL WEIGHTS

v11, v21, v01 = 0.6, -0.1, 0.3
v12, v22, v02 = -0.3, 0.4, 0.5

w1, w2, w0 = 0.4, 0.1, -0.2


# LEARNING RATE

alpha = 0.25

# NUMBER OF EPOCHS

epochs = int(input("Enter number of epochs: "))

# STORE INITIAL WEIGHTS


initial_weights = {
    "v11": v11,
    "v21": v21,
    "v01": v01,
    "v12": v12,
    "v22": v22,
    "v02": v02,
    "w1": w1,
    "w2": w2,
    "w0": w0
}

# STORE UPDATED WEIGHTS AFTER EACH EPOCH

weight_history = []


# STORE ALL CALCULATED VALUES AFTER EACH EPOCH

calculation_history = []


# TRAINING

for epoch in range(1, epochs + 1):

    print(f"\n===== Epoch {epoch} : Forward Pass =====")

    print(f"Inputs: x1 = {x1}, x2 = {x2}")

    print(f"Target: t = {t}")

    print(
        f"Current weights: "
        f"v11={v11:.5f}, "
        f"v21={v21:.5f}, "
        f"v01={v01:.5f}, "
        f"v12={v12:.5f}, "
        f"v22={v22:.5f}, "
        f"v02={v02:.5f}, "
        f"w1={w1:.5f}, "
        f"w2={w2:.5f}, "
        f"w0={w0:.5f}"
    )


    # FORWARD PASS

    # Hidden neuron 1

    z_in1 = v01 + x1 * v11 + x2 * v21

    print(
        f"z_in1 = v01 + x1*v11 + x2*v21 "
        f"= {v01:.5f} + {x1}*{v11:.5f} + "
        f"{x2}*{v21:.5f} = {z_in1:.5f}"
    )


    # Hidden neuron 2

    z_in2 = v02 + x1 * v12 + x2 * v22

    print(
        f"z_in2 = v02 + x1*v12 + x2*v22 "
        f"= {v02:.5f} + {x1}*{v12:.5f} + "
        f"{x2}*{v22:.5f} = {z_in2:.5f}"
    )


    # Hidden outputs

    z1 = sigmoid(z_in1)

    z2 = sigmoid(z_in2)

    print(f"z1 = sigmoid(z_in1) = {z1:.5f}")

    print(f"z2 = sigmoid(z_in2) = {z2:.5f}")


    # OUTPUT LAYER


    y_in = w0 + z1 * w1 + z2 * w2

    print(
        f"y_in = w0 + z1*w1 + z2*w2 "
        f"= {w0:.5f} + {z1:.5f}*{w1:.5f} + "
        f"{z2:.5f}*{w2:.5f} = {y_in:.5f}"
    )


    # Output

    y = sigmoid(y_in)

    print(f"y = sigmoid(y_in) = {y:.5f}")

    # ERROR

    error = t - y


    # OUTPUT DELTA


    f_prime_y_in = y * (1 - y)

    delta_1 = (t - y) * f_prime_y_in



    # OUTPUT WEIGHT CHANGES

    delta_w1 = alpha * delta_1 * z1

    delta_w2 = alpha * delta_1 * z2

    delta_w0 = alpha * delta_1


    # BACK PROPAGATION TO HIDDEN LAYER

    delta_in1 = delta_1 * w1

    delta_in2 = delta_1 * w2


    # HIDDEN LAYER DERIVATIVES

    f_prime_z_in1 = z1 * (1 - z1)

    f_prime_z_in2 = z2 * (1 - z2)


    # HIDDEN LAYER DELTAS

    delta_j1 = delta_in1 * f_prime_z_in1

    delta_j2 = delta_in2 * f_prime_z_in2


    # HIDDEN WEIGHT CHANGES

    # Hidden neuron 1

    delta_v11 = alpha * delta_j1 * x1

    delta_v21 = alpha * delta_j1 * x2

    delta_v01 = alpha * delta_j1


    # Hidden neuron 2

    delta_v12 = alpha * delta_j2 * x1

    delta_v22 = alpha * delta_j2 * x2

    delta_v02 = alpha * delta_j2


    # STORE ALL CALCULATED VALUES


    calculation_history.append({

        # Forward pass
        "z_in1": z_in1,
        "z_in2": z_in2,
        "z1": z1,
        "z2": z2,
        "y_in": y_in,
        "y": y,

        # Error
        "error": error,

        # Deltas
        "delta_1": delta_1,
        "delta_in1": delta_in1,
        "delta_in2": delta_in2,
        "delta_j1": delta_j1,
        "delta_j2": delta_j2,

        # Hidden weight changes
        "delta_v11": delta_v11,
        "delta_v21": delta_v21,
        "delta_v01": delta_v01,

        "delta_v12": delta_v12,
        "delta_v22": delta_v22,
        "delta_v02": delta_v02,

        # Output weight changes
        "delta_w1": delta_w1,
        "delta_w2": delta_w2,
        "delta_w0": delta_w0
    })


    # UPDATE WEIGHTS

    v11 = v11 + delta_v11

    v21 = v21 + delta_v21

    v01 = v01 + delta_v01


    v12 = v12 + delta_v12

    v22 = v22 + delta_v22

    v02 = v02 + delta_v02


    w1 = w1 + delta_w1

    w2 = w2 + delta_w2

    w0 = w0 + delta_w0


    # STORE UPDATED WEIGHTS

    weight_history.append({

        "v11": v11,
        "v21": v21,
        "v01": v01,

        "v12": v12,
        "v22": v22,
        "v02": v02,

        "w1": w1,
        "w2": w2,
        "w0": w0
    })


# SUMMARY TABLE

print("\n")
print("=" * 120)
print("SUMMARY TABLE")
print("=" * 120)


# HEADERS

headers = ["Parameter", "Initial"]

for epoch in range(1, epochs + 1):
    headers.append(f"Epoch {epoch}")


summary_rows = []


# INITIAL + UPDATED WEIGHTS

weight_names = [
    "v11",
    "v21",
    "v01",
    "v12",
    "v22",
    "v02",
    "w1",
    "w2",
    "w0"
]


for weight in weight_names:

    row = [
        weight,
        f"{initial_weights[weight]:.5f}"
    ]

    for epoch in range(epochs):

        row.append(
            f"{weight_history[epoch][weight]:.5f}"
        )

    summary_rows.append(row)


# WEIGHT CHANGE ROWS


delta_names = [
    "delta_v11",
    "delta_v21",
    "delta_v01",
    "delta_v12",
    "delta_v22",
    "delta_v02",
    "delta_w1",
    "delta_w2",
    "delta_w0"
]


for delta_name in delta_names:

    row = [
        delta_name,
        "-"
    ]

    for epoch in range(epochs):

        row.append(
            f"{calculation_history[epoch][delta_name]:.5f}"
        )

    summary_rows.append(row)


# ERROR

error_row = [
    "Error",
    "-"
]

for epoch in range(epochs):

    error_row.append(
        f"{calculation_history[epoch]['error']:.5f}"
    )

summary_rows.append(error_row)


# PRINT SUMMARY TABLE

print(
    tabulate(
        summary_rows,
        headers=headers,
        tablefmt="grid"
    )
)


# FINAL WEIGHTS

print("\n")
print("=" * 80)
print("FINAL WEIGHTS")
print("=" * 80)

print(
    f"v11 = {v11:.7f}, "
    f"v21 = {v21:.7f}, "
    f"v01 = {v01:.7f}"
)

print(
    f"v12 = {v12:.7f}, "
    f"v22 = {v22:.7f}, "
    f"v02 = {v02:.7f}"
)

print(
    f"w1 = {w1:.7f}, "
    f"w2 = {w2:.7f}, "
    f"w0 = {w0:.7f}"
)
