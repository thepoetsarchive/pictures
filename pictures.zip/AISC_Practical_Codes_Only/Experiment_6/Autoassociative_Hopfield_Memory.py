import numpy as np

# KOHONEN SELF-ORGANIZING FEATURE MAP (SOM)

# Initial weight matrix
# Rows = input features
# Columns = output neurons
W = np.array([
    [0.3, 0.2, 0.1, 0.8, 0.4],
    [0.5, 0.6, 0.7, 0.9, 0.2]
], dtype=float)


def kohonen_step(X, alpha, W):
    print("\n" + "=" * 60)
    print("INPUT VECTOR:", X)
    print("LEARNING RATE:", alpha)
    print("=" * 60)

    print("\nCurrent Weight Matrix:")
    print(W)

    # Calculate squared Euclidean distance
    distances = np.sum((W.T - X) ** 2, axis=1)

    print("\nSquared Euclidean Distances:")

    for j, d in enumerate(distances, start=1):
        print(f"D({j}) = {d:.2f}")

    # Find winner
    winner = np.argmin(distances)

    print(f"\nMinimum Distance = {distances[winner]:.2f}")
    print(f"Winner Unit = J = {winner + 1}")

    # Store old weights
    old_weights = W[:, winner].copy()

    # Kohonen weight update:
    # w(new) = w(old) + alpha * [x - w(old)]
    W[:, winner] = old_weights + alpha * (X - old_weights)

    print("\nWeight Update:")
    for i in range(len(X)):
        print(
            f"w{i+1}{winner+1}(new) = "
            f"{old_weights[i]:.2f} + "
            f"{alpha}({X[i]:.2f} - {old_weights[i]:.2f}) "
            f"= {W[i, winner]:.2f}"
        )

    print("\nUpdated Weight Matrix:")
    print(W)

    return W


# FIRST INPUT VECTOR
# X = (0.2, 0.4), alpha = 0.2

X1 = np.array([0.2, 0.4])
W = kohonen_step(X1, 0.2, W)


# SECOND INPUT VECTOR
# X = (0.6, 0.6), alpha = 0.1

X2 = np.array([0.6, 0.6])
W = kohonen_step(X2, 0.1, W)


# FINAL RESULT

print("\n" + "=" * 60)
print("FINAL KOHONEN WEIGHT MATRIX")
print("=" * 60)
print(W)
