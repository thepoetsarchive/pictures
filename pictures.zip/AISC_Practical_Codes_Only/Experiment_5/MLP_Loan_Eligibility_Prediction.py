# Loan Eligibility Prediction

import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score

np.random.seed(42)

income = np.random.randint(20000, 150000, 100)
age = np.random.randint(21, 65, 100)
credit_score = np.random.randint(300, 850, 100)

X = np.column_stack((income, age, credit_score))

y = ((credit_score >= 650) & (income >= 40000)).astype(int)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

model = MLPClassifier(
    hidden_layer_sizes=(16, 8),
    activation='relu',
    max_iter=1000,
    random_state=42
)

model.fit(X_train_scaled, y_train)

predictions = model.predict(X_test_scaled)

print("Actual Test Labels: ", y_test)
print("Predicted Test Labels: ", predictions)
print("Accuracy Score: ", accuracy_score(y_test, predictions))
