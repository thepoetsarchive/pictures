import numpy as np

# LEARNING VECTOR QUANTIZATION (LVQ)

alpha = 0.1

# Initial reference weight vectors
w1 = np.array([0, 0, 1, 1], dtype=float)
w2 = np.array([1, 0, 0, 0], dtype=float)

# Training vectors and their target classes
training_data = [
    (np.array([0, 0, 0, 1], dtype=float), 2),
    (np.array([1, 0, 0, 0], dtype=float), 2),
    (np.array([1, 1, 0, 0], dtype=float), 1)
]

# Reference vector classes
class_w1 = 1
class_w2 = 2


def lvq_step(X, target, w1, w2, alpha):

    print("\n" + "=" * 65)
    print("INPUT VECTOR:", X.astype(int))
    print("TARGET CLASS:", target)
    print("LEARNING RATE:", alpha)
    print("=" * 65)

    print("\nCurrent Reference Vectors:")
    print("w1 =", w1)
    print("w2 =", w2)

    # STEP 1: Calculate squared Euclidean distances

    d1 = np.sum((w1 - X) ** 2)
    d2 = np.sum((w2 - X) ** 2)

    print("\nSquared Euclidean Distances:")
    print(f"D(1) = {d1:.2f}")
    print(f"D(2) = {d2:.2f}")

    # STEP 2: Find winning unit

    if d1 < d2:
        winner = 1
    else:
        winner = 2

    print(f"\nWinner Unit = J = {winner}")

    # STEP 3: Check whether winner's class matches target

    winner_class = class_w1 if winner == 1 else class_w2

    print("Winner Class:", winner_class)
    print("Target Class:", target)

    # STEP 4: Update winner weights

    if winner == 1:

        old = w1.copy()

        if target == winner_class:

            # Correct classification
            # w(new) = w(old) + alpha[x - w(old)]
            w1 = old + alpha * (X - old)

            print("\nCorrect classification.")
            print("Using:")
            print("w(new) = w(old) + alpha * [x - w(old)]")

        else:

            # Incorrect classification
            # w(new) = w(old) - alpha[x - w(old)]
            w1 = old - alpha * (X - old)

            print("\nIncorrect classification.")
            print("Using:")
            print("w(new) = w(old) - alpha * [x - w(old)]")

        print("\nUpdated Winner Vector:")
        print("w1 =", w1)

    else:

        old = w2.copy()

        if target == winner_class:

            # Correct classification
            w2 = old + alpha * (X - old)

            print("\nCorrect classification.")
            print("Using:")
            print("w(new) = w(old) + alpha * [x - w(old)]")

        else:

            # Incorrect classification
            w2 = old - alpha * (X - old)

            print("\nIncorrect classification.")
            print("Using:")
            print("w(new) = w(old) - alpha * [x - w(old)]")

        print("\nUpdated Winner Vector:")
        print("w2 =", w2)

    print("\nUpdated Weight Matrix:")
    print(np.column_stack((w1, w2)))

    return w1, w2


# PROCESS ALL TRAINING VECTORS

for X, target in training_data:

    w1, w2 = lvq_step(
        X,
        target,
        w1,
        w2,
        alpha
    )


# FINAL RESULT

print("\n" + "=" * 65)
print("FINAL LVQ WEIGHT VECTORS")
print("=" * 65)

print("w1 =", w1)
print("w2 =", w2)
