import numpy as np

# Cohen Network

# Input patterns
x1 = np.array([1, 0, 1, 0])
x2 = np.array([0, 1, 0, 1])

# Initialize weights
w = np.zeros((4, 4))

# Hebbian learning
w += np.outer(x1, x1)
w += np.outer(x2, x2)

# Remove self-connections
np.fill_diagonal(w, 0)

print("Weight Matrix:")
print(w)

# Test input
x = np.array([1, 0, 1, 0])

# Network output
y = np.sign(np.dot(w, x))

print("Input:", x)
print("Output:", y)
