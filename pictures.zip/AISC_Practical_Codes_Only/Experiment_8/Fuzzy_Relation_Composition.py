# Question 3: Composition of Two Fuzzy Relations

# Fuzzy relation R (2 x 2)
R = [
    [0.6, 0.3],
    [0.2, 0.9]
]

# Fuzzy relation S (2 x 3)
S = [
    [0.1, 0.5, 0.3],
    [0.8, 0.4, 0.7]
]

rows_R = len(R)
cols_R = len(R[0])
cols_S = len(S[0])

# (a) Max-Min Composition
T_max_min = []

for i in range(rows_R):
    row = []

    for j in range(cols_S):
        values = []

        for k in range(cols_R):
            values.append(min(R[i][k], S[k][j]))

        row.append(max(values))

    T_max_min.append(row)


# (b) Max-Product Composition
T_max_product = []

for i in range(rows_R):
    row = []

    for j in range(cols_S):
        values = []

        for k in range(cols_R):
            values.append(R[i][k] * S[k][j])

        row.append(max(values))

    T_max_product.append(row)


# Function to display a matrix
def display_matrix(matrix):
    for row in matrix:
        print([round(value, 2) for value in row])


print("Fuzzy Relation R:")
display_matrix(R)

print("\nFuzzy Relation S:")
display_matrix(S)


print("\n(a) Max-Min Composition (T = R o S):")
display_matrix(T_max_min)

print("\n(b) Max-Product Composition (T = R o S):")
display_matrix(T_max_product)
