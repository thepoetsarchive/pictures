# Question 6: Operations on Fuzzy Sets

x = [0.64, 0.645, 0.65, 0.655, 0.66]

A = [0, 0.75, 1, 0.5, 0]
B = [0, 0.25, 0.75, 1, 0.5]

union = [max(a, b) for a, b in zip(A, B)]

intersection = [min(a, b) for a, b in zip(A, B)]

complement_A = [1 - a for a in A]

complement_B = [1 - b for b in B]

complement_union = [1 - max(a, b) for a, b in zip(A, B)]

complement_intersection = [1 - min(a, b) for a, b in zip(A, B)]

print("(a) A ∪ B:", union)
print("(b) A ∩ B:", intersection)
print("(c) Complement of A:", complement_A)
print("(d) Complement of B:", complement_B)
print("(e) Complement of union:", complement_union)
print("(f) Complement of intersection:", complement_intersection)
