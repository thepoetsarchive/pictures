import numpy as np

# HETEROASSOCIATIVE MEMORY

# Training input vectors
S = np.array([
    [1, 0, 0, 0],
    [1, 1, 0, 0],
    [0, 0, 0, 1],
    [0, 0, 1, 1]
])

# Target output vectors
T = np.array([
    [0, 1],
    [0, 1],
    [1, 0],
    [1, 0]
])

# CALCULATE WEIGHT MATRIX

# Start with a 4 x 2 integer matrix
W = np.zeros((4, 2), dtype=int)

# Calculate W = sum of outer products
for i in range(len(S)):
    W = W + np.outer(S[i], T[i])

print("Weight Matrix W:")
print(W)


# ACTIVATION FUNCTION

def activation(net):
    if net > 0:
        return 1
    else:
        return 0


# TESTING

for i in range(len(S)):

    # Calculate net input
    net = S[i] @ W

    # Apply activation function
    output = np.array([activation(value) for value in net])

    print("\nInput  :", S[i])
    print("Net    :", net)
    print("Output :", output)
    print("Target :", T[i])
