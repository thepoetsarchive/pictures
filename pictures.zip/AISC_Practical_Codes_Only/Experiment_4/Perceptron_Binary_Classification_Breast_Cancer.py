# 1.Import Libraries

import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay

# 2.Load the Breast Cancer Dataset

# Load the Breast Cancer dataset
data = load_breast_cancer()

# Features
X = data.data

# Target
y = data.target

print("Shape of X:", X.shape)
print("Shape of y:", y.shape)

print("Feature names:")
print(data.feature_names)

print("\nTarget names:")
print(data.target_names)

print("\nTarget values:")
print(np.unique(y))

# 3.Train Test Split

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.3,
    random_state=42
)

print("Training samples:", X_train.shape[0])
print("Testing samples:", X_test.shape[0])

# 4.Preprocessing

from sklearn.preprocessing import StandardScaler

# Create scaler
scaler = StandardScaler()

# Fit scaler only on training data
X_train = scaler.fit_transform(X_train)

# Apply the same transformation to test data
X_test = scaler.transform(X_test)

print("Preprocessing completed.")

print("Training data shape:", X_train.shape)
print("Testing data shape:", X_test.shape)

# 5.Create the Perceptron

clf = Perceptron(
    max_iter=1000,
    eta0=0.1
)

# 6.Train the Model

clf.fit(X_train, y_train)

# 7.Predictions

y_pred = clf.predict(X_test)

print("Predicted values:")
print(y_pred)

# 8.Accuracy

accuracy = accuracy_score(y_test, y_pred)

print("Accuracy:", accuracy)

# 9.Confusion Matrix

conf_matrix = confusion_matrix(y_test, y_pred)

cm_display = ConfusionMatrixDisplay(
    confusion_matrix=conf_matrix,
    display_labels=[False, True]
)

cm_display.plot()
plt.show()
