import numpy as np

# AUTOASSOCIATIVE MEMORY

# Take training input from user
x = list(map(int, input("Enter the input vector: ").split()))
x = np.array(x)

# Calculate weight matrix
W = np.outer(x, x)

print("\nInput Vector:")
print(x)

print("\nWeight Matrix W:")
print(W)


# ACTIVATION FUNCTION

def activation(net):
    if net > 0:
        return 1
    else:
        return -1


# TESTING

test_inputs = [
    x,                              # Same input
    np.array([0, 1, 1, 1]),        # One missing entry
    np.array([-1, -1, 1, 1]),       # One mistake
    np.array([0, 0, 1, 1]),         # Two missing entries
    np.array([-1, -1, -1, 1])       # Two mistakes
]

test_names = [
    "Same Input",
    "One Missing Entry",
    "One Mistake",
    "Two Missing Entries",
    "Two Mistakes"
]

for name, test_input in zip(test_names, test_inputs):

    # Calculate net input
    net = test_input @ W

    # Apply activation function
    output = np.array([activation(value) for value in net])

    print("\n" + name)
    print("--------------------------")
    print("Test Input :", test_input)
    print("Net Input  :", net)
    print("Output     :", output)

    # Check whether the output is correct
    if np.array_equal(output, x):
        print("Result     : Correct - Original pattern recovered")
    else:
        print("Result     : Incorrect - Original pattern not recovered")
