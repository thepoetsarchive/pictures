# 1.HALF ADDER

def mp_neuron(yin, threshold):
    if yin >= threshold:
        return 1
    else:
        return 0


# take the 4 pairs as user input

print("\n")
print("ENTER THE FOUR INPUT PAIRS")

input_pairs = []

for i in range(4):
    print("\nInput Pair", i + 1)

    x1 = int(input("Enter x1 (0 or 1): "))
    x2 = int(input("Enter x2 (0 or 1): "))

    input_pairs.append((x1, x2))


# 1. CARRY USING AND FUNCTION

print("\n")
print("CARRY OUTPUT USING McCULLOCH-PITTS AND NEURON")

# Fixed weights according to the given AND problem
w1 = 1
w2 = 1


# Calculate threshold for AND

carry_zero_yins = []
carry_one_yins = []

for x1, x2 in input_pairs:

    yin = x1 * w1 + x2 * w2

    if x1 == 1 and x2 == 1:
        carry_one_yins.append(yin)
    else:
        carry_zero_yins.append(yin)

theta_carry = min(carry_one_yins)


print("\nFixed weights:")
print("w1 =", w1)
print("w2 =", w2)
print("Calculated Threshold θ =", theta_carry)

print("\nTruth Table and Calculations")
print("-" * 70)
print(f"{'x1':<5}{'x2':<5}{'yin':<10}{'θ':<8}{'Carry(y)':<10}")
print("-" * 70)

carry_results = []

for x1, x2 in input_pairs:

    yin = x1 * w1 + x2 * w2

    carry = mp_neuron(yin, theta_carry)

    carry_results.append((x1, x2, yin, carry))

    print(f"{x1:<5}{x2:<5}{yin:<10}{theta_carry:<8}{carry:<10}")

print("-" * 70)

print("\nActivation condition:")
print(f"Carry = 1  if yin >= {theta_carry}")
print(f"Carry = 0  if yin <  {theta_carry}")


# 2. SUM USING XOR FUNCTION

print("\n\n")
print("SUM OUTPUT USING McCULLOCH-PITTS XOR NEURONS")


# z1

print("\n" + "-" * 70)
print("INTERMEDIATE NEURON Z1")
print("-" * 70)


# Fixed weights
w11 = 1
w12 = -1


# Calculate threshold for Z1
# Z1 = 1 only for x1 = 1, x2 = 0

z1_zero_yins = []
z1_one_yins = []

for x1, x2 in input_pairs:

    yin = x1 * w11 + x2 * w12

    if x1 == 1 and x2 == 0:
        z1_one_yins.append(yin)
    else:
        z1_zero_yins.append(yin)

theta_z1 = min(z1_one_yins)


print("\nFixed weights:")
print("w11 =", w11)
print("w12 =", w12)
print("Calculated Threshold θ1 =", theta_z1)


print("\nActivation:")
print(f"z1 = 1 if z1_in >= {theta_z1}")
print(f"z1 = 0 if z1_in <  {theta_z1}")

print("\nTruth Table and Calculations")
print("-" * 70)
print(f"{'x1':<5}{'x2':<5}{'z1_in':<10}{'θ1':<8}{'z1':<8}")
print("-" * 70)

z1_results = {}

for x1, x2 in input_pairs:

    z1_in = x1 * w11 + x2 * w12

    z1 = mp_neuron(z1_in, theta_z1)

    z1_results[(x1, x2)] = z1

    print(f"{x1:<5}{x2:<5}{z1_in:<10}{theta_z1:<8}{z1:<8}")

print("-" * 70)


# z2

print("\n")
print("INTERMEDIATE NEURON Z2")
print("-" * 70)


# Fixed weights
w21 = -1
w22 = 1


# Calculate threshold for Z2
# Z2 = 1 only for x1 = 0, x2 = 1

z2_zero_yins = []
z2_one_yins = []

for x1, x2 in input_pairs:

    yin = x1 * w21 + x2 * w22

    if x1 == 0 and x2 == 1:
        z2_one_yins.append(yin)
    else:
        z2_zero_yins.append(yin)

theta_z2 = min(z2_one_yins)


print("\nFixed weights:")
print("w21 =", w21)
print("w22 =", w22)
print("Calculated Threshold θ2 =", theta_z2)


print("\nActivation:")
print(f"z2 = 1 if z2_in >= {theta_z2}")
print(f"z2 = 0 if z2_in <  {theta_z2}")

print("\nTruth Table and Calculations")
print("-" * 70)
print(f"{'x1':<5}{'x2':<5}{'z2_in':<10}{'θ2':<8}{'z2':<8}")
print("-" * 70)

z2_results = {}

for x1, x2 in input_pairs:

    z2_in = x1 * w21 + x2 * w22

    z2 = mp_neuron(z2_in, theta_z2)

    z2_results[(x1, x2)] = z2

    print(f"{x1:<5}{x2:<5}{z2_in:<10}{theta_z2:<8}{z2:<8}")

print("-" * 70)


# FINAL XOR NEURON
# y = z1 + z2

print("\n")
print("FINAL XOR NEURON")


# Fixed weights
w_z1 = 1
w_z2 = 1


# Calculate threshold for final XOR

sum_zero_yins = []
sum_one_yins = []

for x1, x2 in input_pairs:

    z1 = mp_neuron(
        x1 * w11 + x2 * w12,
        theta_z1
    )

    z2 = mp_neuron(
        x1 * w21 + x2 * w22,
        theta_z2
    )

    yin = z1 * w_z1 + z2 * w_z2

    if z1 == 1 or z2 == 1:
        sum_one_yins.append(yin)
    else:
        sum_zero_yins.append(yin)

theta_xor = min(sum_one_yins)


print("\nFixed weights:")
print("w_z1 =", w_z1)
print("w_z2 =", w_z2)
print("Calculated Threshold θ =", theta_xor)


print("\nActivation:")
print(f"y = 1 if yin >= {theta_xor}")
print(f"y = 0 if yin <  {theta_xor}")


# FINAL HALF ADDER TABLE

print("\n")
print("FINAL HALF ADDER TRUTH TABLE")
print("-" * 70)

print(
    f"{'x1':<5}"
    f"{'x2':<5}"
    f"{'z1_in':<10}"
    f"{'z1':<6}"
    f"{'z2_in':<10}"
    f"{'z2':<6}"
    f"{'Sum_yin':<10}"
    f"{'Sum':<7}"
    f"{'Carry_yin':<12}"
    f"{'Carry':<7}"
)

print("-" * 70)

for x1, x2 in input_pairs:

    # Z1
    z1_in = x1 * w11 + x2 * w12
    z1 = mp_neuron(z1_in, theta_z1)

    # Z2
    z2_in = x1 * w21 + x2 * w22
    z2 = mp_neuron(z2_in, theta_z2)

    # Final XOR
    sum_yin = z1 * w_z1 + z2 * w_z2
    Sum = mp_neuron(sum_yin, theta_xor)

    # Carry
    carry_yin = x1 * w1 + x2 * w2
    Carry = mp_neuron(carry_yin, theta_carry)

    print(
        f"{x1:<5}"
        f"{x2:<5}"
        f"{z1_in:<10}"
        f"{z1:<6}"
        f"{z2_in:<10}"
        f"{z2:<6}"
        f"{sum_yin:<10}"
        f"{Sum:<7}"
        f"{carry_yin:<12}"
        f"{Carry:<7}"
    )
